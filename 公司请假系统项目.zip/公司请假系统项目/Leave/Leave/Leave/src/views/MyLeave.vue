<template>
  <div class="my-leave-page">
    <el-page-header content="我的请假记录" @back="goBack"></el-page-header>
    <LeaveList /> <!-- 引入请假记录组件 -->
  </div>
</template>

<script setup>
import { useRouter } from 'vue';
import LeaveList from '@/components/LeaveList.vue';

const router = useRouter();
// 返回上一页
const goBack = () => {
  router.back();
};
</script>

<style scoped>
.my-leave-page {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}
</style>