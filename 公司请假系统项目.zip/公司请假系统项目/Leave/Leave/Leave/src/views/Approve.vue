<template>
  <div class="approve-page">
    <el-page-header content="审批中心" @back="goBack"></el-page-header>
    <ApproveList /> <!-- 引入审批列表组件 -->
  </div>
</template>

<script setup>
import { useRouter } from 'vue';
import ApproveList from '@/components/ApproveList.vue';

const router = useRouter();
const goBack = () => {
  router.back();
};
</script>

<style scoped>
.approve-page {
  padding: 20px;
}
</style>