<template>
  <div class="apply-page">
    <el-page-header content="请假申请" @back="goBack"></el-page-header>
    <LeaveApply /> <!-- 引入请假申请组件 -->
  </div>
</template>

<script setup>
import { useRouter } from 'vue';
import LeaveApply from '@/components/LeaveApply.vue';

const router = useRouter();
// 返回上一页
const goBack = () => {
  router.back();
};
</script>

<style scoped>
.apply-page {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}
</style>