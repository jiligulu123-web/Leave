package model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("leave_apply")  // 修正表名
public class LeaveApply {
    @TableId(type = IdType.AUTO)
    private Long id;

    private Long employeeId;  // 修正字段名

    private String leaveType;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private String reason;

    private String status; // PENDING/APPROVED/REJECTED

    private Long approverId;

    private LocalDateTime approveTime;

    private String approveRemark;

    private LocalDateTime createTime;
}