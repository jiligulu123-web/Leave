package com.leave.system.service.command.impl;

import com.leave.system.service.mapper.LeaveApplyMapper;
import model.entity.LeaveApply;
import com.leave.system.service.command.LeaveCommand;
import com.leave.system.service.state.LeaveStateContext;
import com.leave.system.service.state.impl.ApprovedState;
import jakarta.annotation.Resource;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ApproveLeaveCommand implements LeaveCommand {
    private final LeaveApply leaveApply;
    private final String remark;
    private String oldStatus; // 用于撤销

    @Resource
    private LeaveApplyMapper leaveApplyMapper;

    // 添加两个参数的构造器
    public ApproveLeaveCommand(LeaveApply leaveApply, String remark) {
        this.leaveApply = leaveApply;
        this.remark = remark;
        this.oldStatus = leaveApply.getStatus(); // 自动设置oldStatus
    }

    @Override
    public void execute() {
        oldStatus = leaveApply.getStatus();
        // 切换到已同意状态
        LeaveStateContext context = new LeaveStateContext(oldStatus);
        context.changeState(new ApprovedState());
        context.handleState(leaveApply);
        leaveApply.setApproveRemark(remark);
        leaveApplyMapper.updateById(leaveApply);
    }

    @Override
    public void undo() {
        // 撤销操作：恢复原状态
        leaveApply.setStatus(oldStatus);
        leaveApply.setApproveRemark(null);
        leaveApply.setApproveTime(null);
        leaveApplyMapper.updateById(leaveApply);
    }

    @Override
    public LeaveApply getLeaveApply() {
        return leaveApply;
    }
}