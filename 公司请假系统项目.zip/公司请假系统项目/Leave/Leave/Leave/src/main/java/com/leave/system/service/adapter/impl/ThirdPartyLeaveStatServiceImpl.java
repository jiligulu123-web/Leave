package com.leave.system.service.adapter.impl;

import com.leave.system.service.adapter.ThirdPartyLeaveStatService;
import org.springframework.stereotype.Service;

@Service
public class ThirdPartyLeaveStatServiceImpl implements ThirdPartyLeaveStatService {
    @Override
    public String getLeaveStatByDept(String deptName) {
        // 模拟调用第三方接口
        return "{\"total\":10,\"approved\":8,\"rejected\":2}";
    }
}