package com.leave.system.service.iterator;

public interface LeaveContainer {
    LeaveIterator getReverseIterator(); // 获取倒序迭代器
}