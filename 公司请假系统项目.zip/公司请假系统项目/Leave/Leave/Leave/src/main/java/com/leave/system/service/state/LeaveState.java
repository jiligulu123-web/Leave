package com.leave.system.service.state;

import model.entity.LeaveApply;

public interface LeaveState {
    void handle(LeaveApply leaveApply); // 处理状态对应的逻辑
    String getState(); // 获取状态标识
}