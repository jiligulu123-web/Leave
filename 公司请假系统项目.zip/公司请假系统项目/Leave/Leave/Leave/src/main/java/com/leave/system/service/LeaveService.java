package com.leave.system.service;

import model.entity.dto.LeaveApplyDTO;
import model.entity.LeaveApply;
import java.util.List;

public interface LeaveService {
    Long submitApply(LeaveApplyDTO dto);
    List<LeaveApply> getEmployeeList(long empId);
    List<LeaveApply> getEmpLeaveList(Long empId); // 确保这个方法存在
}