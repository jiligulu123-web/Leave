package com.leave.system.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import model.entity.Employee;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmployeeMapper extends BaseMapper<Employee> {
    // 添加分号
}