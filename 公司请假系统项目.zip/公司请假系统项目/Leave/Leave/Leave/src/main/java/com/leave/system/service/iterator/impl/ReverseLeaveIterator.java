package com.leave.system.service.iterator.impl;

import model.entity.LeaveApply;
import com.leave.system.service.iterator.LeaveIterator;
import java.util.List;

public class ReverseLeaveIterator implements LeaveIterator {
    private final List<LeaveApply> leaveList;
    private int index;

    public ReverseLeaveIterator(List<LeaveApply> leaveList) {
        this.leaveList = leaveList;
        this.index = leaveList.size() - 1; // 从最后一个元素开始
    }

    @Override
    public boolean hasNext() {
        return index >= 0;
    }

    @Override
    public LeaveApply next() {
        return leaveList.get(index--);
    }
}