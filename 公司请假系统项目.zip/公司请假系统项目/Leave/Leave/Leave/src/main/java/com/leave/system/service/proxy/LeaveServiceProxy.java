package com.leave.system.service.proxy;

import model.entity.dto.LeaveApplyDTO;
import model.entity.LeaveApply;
import com.leave.system.service.LeaveService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;

@Slf4j
@AllArgsConstructor
public abstract class LeaveServiceProxy implements LeaveService {
    private final LeaveService target; // 被代理的目标对象

    @Override
    public Long submitApply(LeaveApplyDTO dto) {
        // 记录日志（代理额外功能）
        log.info("员工[{}]提交请假申请：类型={}，时间={}至{}",
                dto.getEmpId(), dto.getLeaveType(), dto.getStartTime(), dto.getEndTime());
        // 调用目标对象的核心方法
        Long applyId = target.submitApply(dto);
        log.info("请假申请提交成功，申请ID={}", applyId);
        return applyId;
    }

    @Override
    public List<LeaveApply> getEmpLeaveList(Long empId) {
        log.info("查询员工[{}]的请假记录", empId);
        List<LeaveApply> leaveList = target.getEmpLeaveList(empId);
        log.info("员工[{}]共有{}条请假记录", empId, leaveList.size());
        return leaveList;
    }
}