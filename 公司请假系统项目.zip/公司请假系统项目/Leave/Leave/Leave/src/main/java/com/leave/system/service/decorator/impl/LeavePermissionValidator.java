package com.leave.system.service.decorator.impl;

import com.leave.system.service.mapper.EmployeeMapper;
import model.entity.dto.LeaveApplyDTO;
import model.entity.Employee;
import model.entity.LeaveApply;
import com.leave.system.service.LeaveService;
import com.leave.system.service.decorator.LeaveApplyDecorator;
import jakarta.annotation.Resource;
import java.util.List;

public abstract class LeavePermissionValidator extends LeaveApplyDecorator {
    @Resource
    private EmployeeMapper employeeMapper;

    public LeavePermissionValidator(LeaveService leaveService) {
        super(leaveService);
    }

    @Override
    public Long submitApply(LeaveApplyDTO dto) {
        // 校验审批人是否为部门经理
        Employee approver = employeeMapper.selectById(dto.getApproverId());
        if (!"部门经理".equals(approver.getPosition())) {
            throw new IllegalArgumentException("审批人必须是部门经理");
        }
        return leaveService.submitApply(dto);
    }

    @Override
    public List<LeaveApply> getEmployeeList(long empId) {
        return leaveService.getEmployeeList(empId);
    }
}