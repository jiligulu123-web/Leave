package com.leave.system.service.iterator.impl;

import model.entity.LeaveApply;
import com.leave.system.service.iterator.LeaveContainer;
import com.leave.system.service.iterator.LeaveIterator;
import java.util.List;

public class LeaveListContainer implements LeaveContainer {
    private final List<LeaveApply> leaveList;

    public LeaveListContainer(List<LeaveApply> leaveList) {
        this.leaveList = leaveList;
    }

    @Override
    public LeaveIterator getReverseIterator() {
        return new ReverseLeaveIterator(leaveList);
    }
}