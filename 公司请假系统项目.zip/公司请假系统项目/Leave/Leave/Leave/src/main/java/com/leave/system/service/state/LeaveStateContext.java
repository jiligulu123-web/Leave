package com.leave.system.service.state;

import model.entity.LeaveApply;
import com.leave.system.service.state.impl.ApprovedState;
import com.leave.system.service.state.impl.PendingState;
import com.leave.system.service.state.impl.RejectedState;

public class LeaveStateContext {
    private LeaveState currentState;

    // 根据状态标识初始化状态
    public LeaveStateContext(String status) {
        switch (status) {
            case "PENDING":
                currentState = new PendingState();
                break;
            case "APPROVED":
                currentState = new ApprovedState();
                break;
            case "REJECTED":
                currentState = new RejectedState();
                break;
            default:
                currentState = new PendingState();
        }
    }

    // 切换状态
    public void changeState(LeaveState newState) {
        this.currentState = newState;
    }

    // 执行当前状态的逻辑
    public void handleState(LeaveApply leaveApply) {
        currentState.handle(leaveApply);
    }
}