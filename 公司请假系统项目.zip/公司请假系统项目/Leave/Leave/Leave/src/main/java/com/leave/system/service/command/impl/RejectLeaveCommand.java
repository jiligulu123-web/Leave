package com.leave.system.service.command.impl;

import com.leave.system.service.mapper.LeaveApplyMapper;
import model.entity.LeaveApply;
import com.leave.system.service.command.LeaveCommand;
import com.leave.system.service.state.LeaveStateContext;
import com.leave.system.service.state.impl.RejectedState;
import jakarta.annotation.Resource;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class RejectLeaveCommand implements LeaveCommand {
    private final LeaveApply leaveApply;
    private final String remark;
    private String oldStatus;

    @Resource
    private LeaveApplyMapper leaveApplyMapper;

    // 两个参数的构造器
    public RejectLeaveCommand(LeaveApply leaveApply, String remark) {
        this.leaveApply = leaveApply;
        this.remark = remark;
        this.oldStatus = leaveApply.getStatus();
    }

    @Override
    public void execute() {
        oldStatus = leaveApply.getStatus();
        LeaveStateContext context = new LeaveStateContext(oldStatus);
        context.changeState(new RejectedState());
        context.handleState(leaveApply);
        leaveApply.setApproveRemark(remark);
        leaveApplyMapper.updateById(leaveApply);
    }

    @Override
    public void undo() {
        leaveApply.setStatus(oldStatus);
        leaveApply.setApproveRemark(null);
        leaveApply.setApproveTime(null);
        leaveApplyMapper.updateById(leaveApply);
    }

    @Override
    public LeaveApply getLeaveApply() {
        return leaveApply;
    }
}