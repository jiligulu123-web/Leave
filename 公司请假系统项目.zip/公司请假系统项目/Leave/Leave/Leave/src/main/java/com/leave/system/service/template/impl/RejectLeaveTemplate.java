package com.leave.system.service.template.impl;

import model.entity.LeaveApply;
import com.leave.system.service.command.CommandInvoker;
import com.leave.system.service.command.LeaveCommand;
import com.leave.system.service.command.impl.RejectLeaveCommand;
import com.leave.system.service.observer.LeaveSubject;
import com.leave.system.service.template.LeaveApproveTemplate;

public class RejectLeaveTemplate extends LeaveApproveTemplate {
    public RejectLeaveTemplate(CommandInvoker commandInvoker, LeaveSubject leaveSubject) {
        super(commandInvoker, leaveSubject);
    }

    @Override
    protected void validate(LeaveApply leaveApply) {
        // 驳回审批的校验逻辑：同同意审批
        if (!"PENDING".equals(leaveApply.getStatus())) {
            throw new IllegalArgumentException("只能审批待审批状态的申请");
        }
    }

    @Override
    protected LeaveCommand createCommand(LeaveApply leaveApply, String remark) {
        return new RejectLeaveCommand(leaveApply, remark); // 改为2个参数
    }

    public void reject(LeaveApply leaveApply, String remark) {
        execute(leaveApply, remark); // 添加具体实现
    }

    private void execute(LeaveApply leaveApply, String remark) {
    }
}