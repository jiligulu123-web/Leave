package com.leave.system.service.observer;

import model.entity.LeaveApply;

public interface Observer {
    void update(LeaveApply leaveApply); // 接收通知并处理
}