package com.leave.system.service.observer.impl;

import model.entity.LeaveApply;
import model.entity.Notification;
import com.leave.system.service.mapper.NotificationMapper;
import com.leave.system.service.observer.Observer;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDateTime;

@Slf4j
public class ApplicantObserver implements Observer {
    @Resource
    private NotificationMapper notificationMapper;

    @Override
    public void update(LeaveApply leaveApply) {
        String content;
        switch (leaveApply.getStatus()) {
            case "APPROVED":
                content = "您的请假申请（ID: " + leaveApply.getId() + "）已同意！";
                break;
            case "REJECTED":
                content = "您的请假申请（ID: " + leaveApply.getId() + "）已驳回，备注：" + leaveApply.getApproveRemark();
                break;
            default:
                content = "您的请假申请（ID: " + leaveApply.getId() + "）状态已更新为" + leaveApply.getStatus();
        }

        // 保存通知
        Notification notification = new Notification();
        notification.setUserId(leaveApply.getEmployeeId()); // 修正字段名
        notification.setContent(content);
        notification.setIsRead(false); // 修正为boolean
        notification.setCreateTime(LocalDateTime.now());
        notificationMapper.insert(notification);
        log.info("已向申请人[{}]发送通知: {}", leaveApply.getEmployeeId(), content);
    }
}