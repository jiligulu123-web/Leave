package com.leave.system.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.leave.system.service.mapper.LeaveApplyMapper;
import model.entity.dto.LeaveApplyDTO;
import model.entity.LeaveApply;
import com.leave.system.service.observer.LeaveSubject;
import com.leave.system.service.observer.impl.ApproverObserver;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class LeaveServiceImpl implements LeaveService {
    @Resource
    private LeaveApplyMapper leaveApplyMapper;

    @Resource
    private LeaveSubject leaveSubject;

    @Override
    public Long submitApply(LeaveApplyDTO dto) {
        // 1. 转换DTO为实体
        LeaveApply leaveApply = new LeaveApply();
        leaveApply.setEmployeeId(dto.getEmpId());
        leaveApply.setLeaveType(dto.getLeaveType());
        leaveApply.setStartTime(dto.getStartTime());
        leaveApply.setEndTime(dto.getEndTime());
        leaveApply.setReason(dto.getReason());
        leaveApply.setApproverId(dto.getApproverId());
        leaveApply.setStatus("PENDING");
        leaveApply.setCreateTime(LocalDateTime.now());

        // 2. 保存到数据库
        leaveApplyMapper.insert(leaveApply);
        return leaveApply.getId();
    }

    @Override
    public List<LeaveApply> getEmployeeList(long empId) {
        return leaveApplyMapper.selectList(new LambdaQueryWrapper<LeaveApply>()
                .eq(LeaveApply::getEmployeeId, empId));
    }

    @Override
    public List<LeaveApply> getEmpLeaveList(Long empId) {
        return getEmployeeList(empId); // 或者实现具体逻辑
    }
}