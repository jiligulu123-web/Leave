package com.leave.system.service.adapter;

// 第三方系统的请假统计接口（方法名、参数与当前系统不一致）
public interface ThirdPartyLeaveStatService {
    // 返回格式：{ "total": 10, "approved": 8, "rejected": 2 }
    String getLeaveStatByDept(String deptName);
}