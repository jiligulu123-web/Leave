package com.leave.system.service.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.leave.system.service.mapper.LeaveApplyMapper;
import model.entity.dto.LeaveApplyDTO;
import model.entity.LeaveApply;
import model.entity.vo.LeaveStatVO;
import model.entity.vo.ResultVO;
import com.leave.system.service.LeaveService;
import com.leave.system.service.adapter.LeaveStatService;
import com.leave.system.service.adapter.impl.ThirdPartyLeaveStatAdapter;
import com.leave.system.service.adapter.impl.ThirdPartyLeaveStatServiceImpl;
import com.leave.system.service.command.CommandInvoker;
import com.leave.system.service.iterator.LeaveContainer;
import com.leave.system.service.iterator.LeaveIterator;
import com.leave.system.service.iterator.impl.LeaveListContainer;
import com.leave.system.service.observer.LeaveSubject;
import com.leave.system.service.template.impl.ApproveLeaveTemplate;
import com.leave.system.service.template.impl.RejectLeaveTemplate;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/leave")
public class LeaveController {
    @Resource
    private LeaveService leaveService;
    @Resource
    private LeaveApplyMapper leaveApplyMapper;
    @Resource
    private CommandInvoker commandInvoker;
    @Resource
    private LeaveSubject leaveSubject;

    // 批准请假
    @PostMapping("/approve/{applyId}")
    public ResultVO<Void> approveLeave(@PathVariable Long applyId, @RequestParam String remark) {
        LeaveApply leaveApply = leaveApplyMapper.selectById(applyId);
        ApproveLeaveTemplate template = new ApproveLeaveTemplate(commandInvoker, leaveSubject);
        template.approve(leaveApply, remark); // 修正方法调用
        return ResultVO.success("审批通过");
    }

    // 驳回请假
    @PostMapping("/reject/{applyId}")
    public ResultVO<Void> rejectLeave(@PathVariable Long applyId, @RequestParam String remark) {
        LeaveApply leaveApply = leaveApplyMapper.selectById(applyId);
        RejectLeaveTemplate template = new RejectLeaveTemplate(commandInvoker, leaveSubject);
        template.reject(leaveApply, remark); // 修正方法调用
        return ResultVO.success("审批驳回");
    }

    // 查询部门请假统计（适配器模式）
    @GetMapping("/stat/dept/{deptName}")
    public ResultVO<LeaveStatVO> getDeptLeaveStat(@PathVariable String deptName) {
        LeaveStatService statService = new ThirdPartyLeaveStatAdapter(new ThirdPartyLeaveStatServiceImpl());
        LeaveStatVO statVO = statService.getDeptLeaveStat(deptName);
        return ResultVO.success(statVO);
    }

    // 查询待审批列表
    @GetMapping("/approve/list/{approverId}")
    public ResultVO<List<LeaveApply>> getApprovalList(@PathVariable Long approverId) {
        List<LeaveApply> list = leaveApplyMapper.selectList(new LambdaQueryWrapper<LeaveApply>()
                .eq(LeaveApply::getApproverId, approverId)
                .eq(LeaveApply::getStatus, "PENDING")
                .orderByDesc(LeaveApply::getCreateTime));
        return ResultVO.success(list);
    }
}