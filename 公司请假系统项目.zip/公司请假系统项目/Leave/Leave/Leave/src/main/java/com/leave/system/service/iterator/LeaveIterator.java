package com.leave.system.service.iterator;

import model.entity.LeaveApply;

public interface LeaveIterator {
    boolean hasNext(); // 是否有下一个元素
    LeaveApply next(); // 获取下一个元素
}