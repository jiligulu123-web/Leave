package com.leave.system.service.adapter;

import model.entity.vo.LeaveStatVO;

public interface LeaveStatService {
    LeaveStatVO getDeptLeaveStat(String deptName);
}