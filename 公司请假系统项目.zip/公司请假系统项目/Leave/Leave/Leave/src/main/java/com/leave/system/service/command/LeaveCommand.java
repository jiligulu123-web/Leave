package com.leave.system.service.command;

import model.entity.LeaveApply;

public interface LeaveCommand {
    void execute(); // 执行命令
    void undo();    // 撤销命令（可选）
    LeaveApply getLeaveApply(); // 获取关联的请假申请
}