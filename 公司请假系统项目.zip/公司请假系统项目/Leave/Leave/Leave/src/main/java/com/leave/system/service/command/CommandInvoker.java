package com.leave.system.service.command;

import java.util.Stack;

public class CommandInvoker {
    private final Stack<LeaveCommand> commandStack = new Stack<>(); // 用于撤销操作

    // 执行命令
    public void executeCommand(LeaveCommand command) {
        command.execute();
        commandStack.push(command);
    }

    // 撤销上一个命令
    public void undoLastCommand() {
        if (!commandStack.isEmpty()) {
            LeaveCommand command = commandStack.pop();
            command.undo();
        }
    }
}