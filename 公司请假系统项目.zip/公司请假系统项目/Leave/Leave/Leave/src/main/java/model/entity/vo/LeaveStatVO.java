package model.entity.vo;

import lombok.Data;

@Data
public class LeaveStatVO {
    private String deptName;
    private Integer total;
    private Integer approved;
    private Integer rejected;

    // 构造函数
    public LeaveStatVO() {}

    public LeaveStatVO(String deptName, Integer total, Integer approved, Integer rejected) {
        this.deptName = deptName;
        this.total = total;
        this.approved = approved;
        this.rejected = rejected;
    }
}