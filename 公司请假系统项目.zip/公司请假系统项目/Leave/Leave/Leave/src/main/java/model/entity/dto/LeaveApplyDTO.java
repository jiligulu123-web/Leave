package model.entity.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class LeaveApplyDTO {
    private Long empId; // 申请人ID
    private String leaveType; // 请假类型
    private LocalDateTime startTime; // 开始时间
    private LocalDateTime endTime; // 结束时间
    private String reason; // 请假原因
    private Long approverId; // 审批人ID
}