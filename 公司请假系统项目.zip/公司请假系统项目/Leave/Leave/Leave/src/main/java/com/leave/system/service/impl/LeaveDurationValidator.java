package com.leave.system.service.impl;

import model.entity.dto.LeaveApplyDTO;
import model.entity.LeaveApply;
import com.leave.system.service.LeaveService;
import com.leave.system.service.LeaveApplyDecorator;
import java.time.Duration;
import java.util.List;

public abstract class LeaveDurationValidator extends LeaveApplyDecorator {
    public LeaveDurationValidator(LeaveService leaveService) {
        super(leaveService);
    }

    @Override
    public Long submitApply(LeaveApplyDTO dto) {
        // 校验请假时长（年假最多15天）
        if ("年假".equals(dto.getLeaveType())) {
            long days = Duration.between(dto.getStartTime(), dto.getEndTime()).toDays();
            if (days > 15) {
                throw new IllegalArgumentException("年假最长可申请15天");
            }
        }
        return leaveService.submitApply(dto);
    }

    @Override
    public List<LeaveApply> getEmployeeList(long empId) {
        return leaveService.getEmployeeList(empId);
    }
}