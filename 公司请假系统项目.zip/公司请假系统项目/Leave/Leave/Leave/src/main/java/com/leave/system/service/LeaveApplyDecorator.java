package com.leave.system.service;

import model.entity.LeaveApply;
import model.entity.dto.LeaveApplyDTO;

import java.util.List;

public abstract class LeaveApplyDecorator implements LeaveService {
    protected LeaveService leaveService; // 被装饰的对象

    public LeaveApplyDecorator(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @Override
    public abstract Long submitApply(LeaveApplyDTO dto);

    @Override
    public abstract List<LeaveApply> getEmpLeaveList(Long empId);
}