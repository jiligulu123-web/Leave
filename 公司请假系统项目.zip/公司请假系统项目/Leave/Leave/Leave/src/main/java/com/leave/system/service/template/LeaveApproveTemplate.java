package com.leave.system.service.template;

import model.entity.LeaveApply;
import com.leave.system.service.command.CommandInvoker;
import com.leave.system.service.command.LeaveCommand;
import com.leave.system.service.observer.LeaveSubject;
import com.leave.system.service.observer.impl.ApplicantObserver;

public abstract class LeaveApproveTemplate {
    protected CommandInvoker commandInvoker;
    protected LeaveSubject leaveSubject;

    public LeaveApproveTemplate(CommandInvoker commandInvoker, LeaveSubject leaveSubject) {
        this.commandInvoker = commandInvoker;
        this.leaveSubject = leaveSubject;
    }

    // 模板方法：定义固定流程
    public final void approve(LeaveApply leaveApply, String remark) {
        // 1. 校验申请（抽象方法，子类实现）
        validate(leaveApply);
        // 2. 执行审批（核心业务，固定）
        LeaveCommand command = createCommand(leaveApply, remark);
        commandInvoker.executeCommand(command);
        // 3. 通知申请人（固定）
        leaveSubject.registerObserver(new ApplicantObserver());
        leaveSubject.notifyObservers(leaveApply);
    }

    // 抽象方法：校验逻辑（子类实现）
    protected abstract void validate(LeaveApply leaveApply);

    // 抽象方法：创建审批命令（子类实现）
    protected abstract LeaveCommand createCommand(LeaveApply leaveApply, String remark);
}