package com.leave.system.service.state.impl;

import model.entity.LeaveApply;
import com.leave.system.service.state.LeaveState;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PendingState implements LeaveState {
    @Override
    public void handle(LeaveApply leaveApply) {
        log.info("请假申请[{}]进入待审批状态，等待审批人处理", leaveApply.getId());
        leaveApply.setStatus(getState());
    }

    @Override
    public String getState() {
        return "PENDING";
    }
}