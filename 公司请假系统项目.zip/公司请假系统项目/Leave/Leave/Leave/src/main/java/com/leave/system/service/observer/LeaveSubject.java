package com.leave.system.service.observer;

import model.entity.LeaveApply;
import java.util.ArrayList;
import java.util.List;

public class LeaveSubject {
    private final List<Observer> observers = new ArrayList<>();

    // 注册观察者
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    // 移除观察者
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    // 通知所有观察者
    public void notifyObservers(LeaveApply leaveApply) {
        for (Observer observer : observers) {
            observer.update(leaveApply);
        }
    }
}