package com.leave.system.service.adapter.impl;

import com.alibaba.fastjson2.JSONObject; // 修正导入
import model.entity.vo.LeaveStatVO;
import com.leave.system.service.adapter.LeaveStatService; // 修正接口名
import com.leave.system.service.adapter.ThirdPartyLeaveStatService; // 修正接口名
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ThirdPartyLeaveStatAdapter implements LeaveStatService { // 修正接口名
    private final ThirdPartyLeaveStatService thirdPartyService;

    @Override
    public LeaveStatVO getDeptLeaveStat(String deptName) { // 修正参数名
        // 1. 调用第三方接口
        String thirdPartyResult = thirdPartyService.getLeaveStatByDept(deptName);
        // 2. 解析第三方数据
        JSONObject json = JSONObject.parseObject(thirdPartyResult);
        // 3. 转换为当前系统的VO格式
        LeaveStatVO vo = new LeaveStatVO();
        vo.setDeptName(deptName);
        vo.setTotal(json.getInteger("total"));
        vo.setApproved(json.getInteger("approved"));
        vo.setRejected(json.getInteger("rejected"));
        return vo;
    }
}