package com.leave.system.service.state.impl;

import model.entity.LeaveApply;
import com.leave.system.service.state.LeaveState;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDateTime;

@Slf4j
public class RejectedState implements LeaveState {
    @Override
    public void handle(LeaveApply leaveApply) {
        log.info("请假申请[{}]已驳回", leaveApply.getId());
        leaveApply.setStatus(getState());
        leaveApply.setApproveTime(LocalDateTime.now());
    }

    @Override
    public String getState() {
        return "REJECTED";
    }
}