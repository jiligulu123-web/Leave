package com.leave.system.service.template.impl;

import model.entity.LeaveApply;
import com.leave.system.service.command.CommandInvoker;
import com.leave.system.service.command.impl.ApproveLeaveCommand;
import com.leave.system.service.command.LeaveCommand;
import com.leave.system.service.observer.LeaveSubject;
import com.leave.system.service.template.LeaveApproveTemplate;

public class ApproveLeaveTemplate extends LeaveApproveTemplate {
    public ApproveLeaveTemplate(CommandInvoker commandInvoker, LeaveSubject leaveSubject) {
        super(commandInvoker, leaveSubject);
    }

    @Override
    protected void validate(LeaveApply leaveApply) {
        // 同意审批的校验逻辑，只能审批待审批状态的申请
        if (!"PENDING".equals(leaveApply.getStatus())) {
            throw new IllegalArgumentException("只能审批待审批状态的申请");
        }
    }

    @Override
    protected LeaveCommand createCommand(LeaveApply leaveApply, String remark) {
        return new ApproveLeaveCommand(leaveApply, remark);
    }
}