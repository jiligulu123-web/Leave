package com.leave.system.service.observer.impl;

import com.leave.system.service.mapper.NotificationMapper;
import model.entity.LeaveApply;
import model.entity.Notification;
import com.leave.system.service.observer.Observer;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDateTime;

@Slf4j
public class ApproverObserver implements Observer {
    @Resource
    private NotificationMapper notificationMapper;

    @Override
    public void update(LeaveApply leaveApply) {
        if ("PENDING".equals(leaveApply.getStatus())) {
            String content = "您有新的请假申请需要审批 (ID: " + leaveApply.getId() + ".申请人: " + leaveApply.getEmployeeId() + ")";
            Notification notification = new Notification();
            notification.setUserId(leaveApply.getApproverId());
            notification.setContent(content);
            notification.setIsRead(false); // 修正为boolean
            notification.setCreateTime(LocalDateTime.now()); // 修正拼写
            notificationMapper.insert(notification);
            log.info("已向审批人[{}]发送通知: {}", leaveApply.getApproverId(), content);
        }
    }
}