package com.leave.system.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import model.entity.Notification;  // 修正类名
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface NotificationMapper extends BaseMapper<Notification> {
}