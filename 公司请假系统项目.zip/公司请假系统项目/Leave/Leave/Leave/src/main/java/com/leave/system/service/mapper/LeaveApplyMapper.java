package com.leave.system.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import model.entity.LeaveApply;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LeaveApplyMapper extends BaseMapper<LeaveApply> {
}