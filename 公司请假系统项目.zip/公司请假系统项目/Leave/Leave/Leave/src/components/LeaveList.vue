<template>
  <el-card title="我的请假记录">
    <el-table :data="leaveList" border style="width: 100%">
      <el-table-column label="申请ID" prop="id"></el-table-column>
      <el-table-column label="请假类型" prop="leaveType"></el-table-column>
      <el-table-column label="开始时间" prop="startTime" :formatter="formatTime"></el-table-column>
      <el-table-column label="结束时间" prop="endTime" :formatter="formatTime"></el-table-column>
      <el-table-column label="状态" prop="status">
        <template #default="scope">
          <el-tag :type="scope.row.status === 'APPROVED' ? 'success' : scope.row.status === 'REJECTED' ? 'danger' : 'warning'">
            {{ scope.row.status === 'APPROVED' ? '已同意' : scope.row.status === 'REJECTED' ? '已驳回' : '待审批' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="审批备注" prop="approveRemark" :show-overflow-tooltip="true"></el-table-column>
    </el-table>
  </el-card>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { getEmpLeaveList } from '@/api/leave';

const empId = ref(1); // 模拟当前登录员工ID
const leaveList = ref([]);

const formatTime = (row, column) => {
  return row[column.prop] ? new Date(row[column.prop]).toLocaleString() : '';
};

const fetchLeaveList = async () => {
  try {
    const res = await getEmpLeaveList(empId.value);
    leaveList.value = res.data.data;
  } catch (error) {
    ElMessage.error('查询请假记录失败');
  }
};

onMounted(() => {
  fetchLeaveList();
});
</script>