<template>
  <el-card title="待审批请假申请">
    <el-table :data="approveList" border style="width: 100%">
      <el-table-column label="申请ID" prop="id"></el-table-column>
      <el-table-column label="申请人ID" prop="empId"></el-table-column>
      <el-table-column label="请假类型" prop="leaveType"></el-table-column>
      <el-table-column label="开始时间" prop="startTime" :formatter="formatTime"></el-table-column>
      <el-table-column label="结束时间" prop="endTime" :formatter="formatTime"></el-table-column>
      <el-table-column label="请假原因" prop="reason" :show-overflow-tooltip="true"></el-table-column>
      <el-table-column label="操作">
        <template #default="scope">
          <el-button type="success" size="small" @click="handleApprove(scope.row)">同意</el-button>
          <el-button type="danger" size="small" @click="handleReject(scope.row)" style="margin-left: 5px;">驳回</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { getApprovalList, approveLeave, rejectLeave } from '@/api/leave'; // 需补充对应API

// 模拟当前审批人ID（实际应从登录态获取）
const approverId = ref(1);
const approveList = ref([]);

// 格式化时间
const formatTime = (row, column) => {
  return row[column.prop] ? new Date(row[column.prop]).toLocaleString() : '';
};

// 获取待审批列表
const fetchApprovalList = async () => {
  try {
    const res = await getApprovalList(approverId.value);
    approveList.value = res.data.data;
  } catch (error) {
    ElMessage.error('查询待审批列表失败');
  }
};

// 同意审批
const handleApprove = async (row) => {
  try {
    await ElMessageBox.prompt('请输入审批备注', '提示', {
      type: 'success'
    }).then(async ({ value }) => {
      await approveLeave(row.id, value);
      ElMessage.success('审批通过！');
      fetchApprovalList(); // 刷新列表
    });
  } catch (error) {
    ElMessage.info('已取消操作');
  }
};

// 驳回审批
const handleReject = async (row) => {
  try {
    await ElMessageBox.prompt('请输入驳回原因', '提示', {
      type: 'warning'
    }).then(async ({ value }) => {
      await rejectLeave(row.id, value);
      ElMessage.success('已驳回！');
      fetchApprovalList(); // 刷新列表
    });
  } catch (error) {
    ElMessage.info('已取消操作');
  }
};

// 页面加载时获取列表
onMounted(() => {
  fetchApprovalList();
});
</script>