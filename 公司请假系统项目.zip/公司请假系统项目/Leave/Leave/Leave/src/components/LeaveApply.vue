<template>
  <el-card title="请假申请">
    <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
      <el-form-item label="请假类型" prop="leaveType">
        <el-select v-model="form.leaveType" placeholder="请选择请假类型">
          <el-option label="事假" value="事假"></el-option>
          <el-option label="病假" value="病假"></el-option>
          <el-option label="年假" value="年假"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="开始时间" prop="startTime">
        <el-date-picker v-model="form.startTime" type="datetime" placeholder="选择开始时间"></el-date-picker>
      </el-form-item>
      <el-form-item label="结束时间" prop="endTime">
        <el-date-picker v-model="form.endTime" type="datetime" placeholder="选择结束时间"></el-date-picker>
      </el-form-item>
      <el-form-item label="请假原因" prop="reason">
        <el-input v-model="form.reason" type="textarea" :rows="5" placeholder="请输入请假原因"></el-input>
      </el-form-item>
      <el-form-item label="审批人ID" prop="approverId">
        <el-input v-model="form.approverId" type="number" placeholder="请输入审批人ID"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm">提交申请</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script setup>
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { submitLeaveApply } from '@/api/leave';

const formRef = ref(null);
const form = ref({
  leaveType: '',
  startTime: '',
  endTime: '',
  reason: '',
  approverId: '',
  empId: 1 // 模拟当前登录员工ID
});

const rules = ref({
  leaveType: [{ required: true, message: '请选择请假类型', trigger: 'change' }],
  startTime: [{ required: true, message: '请选择开始时间', trigger: 'change' }],
  endTime: [{ required: true, message: '请选择结束时间', trigger: 'change' }],
  reason: [{ required: true, message: '请输入请假原因', trigger: 'blur' }],
  approverId: [{ required: true, message: '请输入审批人ID', trigger: 'blur' }]
});

const submitForm = async () => {
  try {
    await formRef.value.validate();
    const res = await submitLeaveApply(form.value);
    ElMessage.success('申请提交成功，申请ID：' + res.data.data);
    formRef.value.resetFields();
  } catch (error) {
    ElMessage.error(error.message || '申请提交失败');
  }
};
</script>