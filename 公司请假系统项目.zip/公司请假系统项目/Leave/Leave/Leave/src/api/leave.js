import axios from 'axios';

// 提交请假申请
export function submitLeaveApply(data) {
    return axios.post('/leave/apply', data);
}

// 查询员工请假记录
export function getEmpLeaveList(empId) {
    return axios.get(`/leave/emp/${empId}`);
}

// 同意请假
export function approveLeave(applyId, remark) {
    return axios.post(`/leave/approve/${applyId}`, {}, { params: { remark } });
}

// 驳回请假
export function rejectLeave(applyId, remark) {
    return axios.post(`/leave/reject/${applyId}`, {}, { params: { remark } });
}

// 查询部门请假统计
export function getDeptLeaveStat(deptName) {
    return axios.get(`/leave/stat/dept/${deptName}`);
}
// api/leave.js 新增待审批列表接口
export function getApprovalList(approverId) {
    return axios.get(`/leave/approve/list/${approverId}`);
}