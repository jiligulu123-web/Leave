import { createRouter, createWebHistory } from 'vue-router';
import Apply from '@/views/Apply.vue';
import MyLeave from '@/views/MyLeave.vue';
import Approve from '@/views/Approve.vue';

const routes = [
    { path: '/', redirect: '/apply' },
    { path: '/apply', component: Apply, name: '请假申请' },
    { path: '/my-leave', component: MyLeave, name: '我的请假' },
    { path: '/approve', component: Approve, name: '审批中心' }
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

export default router;